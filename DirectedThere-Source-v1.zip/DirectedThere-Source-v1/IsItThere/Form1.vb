﻿Imports System.IO

Public Class Form1
    Dim AllURLSTOCHECK As String
    Private path As String = ("HQ_Admin_List.txt")
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ListBox1.Items.Add(TextBox1.Text)
        Label8.Text = "Count: " & ListBox1.Items.Count
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        BackgroundWorker1.RunWorkerAsync()
        Timer1.Start()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label8.Text = "Count: " & ListBox1.Items.Count
    End Sub

    Private Sub BackgroundWorker1_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork
        For i = 0 To ListBox1.Items.Count - 1

            GrabURL(i)
            CheckURL()

            Label4.Text = "Checking Urls..."
            Label4.ForeColor = Color.Lime

            If i = ListBox1.Items.Count - 1 Then

                Label4.Text = "Done Working!"
                Label4.ForeColor = Color.IndianRed
                MessageBox.Show("We are done checking all open directorys and index's")

            End If
        Next
    End Sub

    Private Sub GrabURL(i As Integer) ' Does the work
        Dim AllURL As String = ListBox1.Items.Item(i)
        Dim Urls As String = AllURL.ToLower

        AllURLSTOCHECK = AllURL

    End Sub
    Public Sub CheckURL()
        Dim request As Net.HttpWebRequest = Net.WebRequest.Create(TextBox2.Text & AllURLSTOCHECK)
        On Error Resume Next
        Dim response As Net.HttpWebResponse = request.GetResponse()

        Dim sReader As StreamReader = New StreamReader(response.GetResponseStream)
        Dim UrlResults As String = sReader.ReadToEnd()

        '' If the indexs in html / php =. contains "" Then call forms
        If UrlResults.Contains("404 , Nothing here , not found , Not Found") Then
            HTTPError()

        Else
            Working()
        End If
    End Sub

    Public Sub HTTPError()
        CheckForIllegalCrossThreadCalls = False

        If CheckBox2.Checked = False Then
            ListBox2.Items.Add(TextBox2.Text + AllURLSTOCHECK + " = " + TextBox4.Text)
            AllURLSTOCHECK = ""
        ElseIf CheckBox2.Checked = True Then
            AllURLSTOCHECK = ""
        End If
    End Sub
    Public Sub Working()
        CheckForIllegalCrossThreadCalls = False
        ListBox2.Items.Add(TextBox2.Text + AllURLSTOCHECK + " = " + TextBox5.Text)
        AllURLSTOCHECK = ""
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        ListBox2.Items.Clear()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        '  ProgressBar1.Value = BackgroundWorker1.WorkerReportsProgress

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        WebBrowser1.Navigate("www.google.com")
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        WebBrowser1.Navigate("https://www.youtube.com/watch?v=yc7_NHx6oHw")
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs)
        WebBrowser1.Navigate(TextBox3.Text)
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged

    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        ListBox1.Items.Clear()
    End Sub

    Private Sub CheckBox4_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox4.CheckedChanged
        If Me.CheckBox4.Checked = True Then
            Me.TopMost = True
        Else
            Me.TopMost = False
        End If
    End Sub

    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged
        If Me.CheckBox3.Checked = True Then
            Me.ShowInTaskbar = True
        Else
            Me.ShowInTaskbar = False
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked

    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Dim openfile = New OpenFileDialog()
        openfile.Filter = "Text (*.txt)|*.txt"
        If (openfile.ShowDialog() = System.Windows.Forms.DialogResult.OK) Then
            Dim myfile As String = openfile.FileName
            Dim allLines As String() = File.ReadAllLines(myfile)
            For Each line As String In allLines
                ListBox1.Items.Add(line)
            Next
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim SetSave As SaveFileDialog = New SaveFileDialog
        Dim i As Integer
        SetSave.Title = "Save URLS"
        SetSave.Filter = "(*.txt)|*.txt"

        If SetSave.ShowDialog = Me.DialogResult.OK Then
            Dim s As New IO.StreamWriter(SetSave.FileName, True)
            For i = 0 To ListBox1.Items.Count - 1
                s.WriteLine(ListBox2.Items.Item(i))
            Next
            s.Close()
        End If
    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click
        BackgroundWorker1.CancelAsync()
    End Sub

    Private Sub Button8_Click_1(sender As Object, e As EventArgs) Handles Button8.Click
        WebBrowser1.Navigate(TextBox3.Text)
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        ColorDialog1.ShowDialog()
        Label1.ForeColor = ColorDialog1.Color
    End Sub

    Private Sub CheckBox5_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox5.CheckedChanged

    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        FontDialog1.ShowDialog()
        Label1.Font = FontDialog1.Font
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click

        ListBox1.Items.Clear()
        ListBox1.Items.AddRange(File.ReadAllLines(path))

    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        Credits.Show()
    End Sub
End Class
