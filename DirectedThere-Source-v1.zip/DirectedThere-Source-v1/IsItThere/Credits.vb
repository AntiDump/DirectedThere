﻿Public Class Credits
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Credits_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class